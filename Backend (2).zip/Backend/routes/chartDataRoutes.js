const express = require('express');
const router = express.Router();
const ChartData = require('../models/ChartData'); // Ensure the model is correctly defined and the path is correct

// Route for hardcoded data
router.get('/static-chart-data', (req, res) => {
  res.json({
    title: 'Static Investment Trends',
    labels: ['January', 'February', 'March', 'April', 'May', 'June'],
    datasets: [
      {
        label: 'Static Data',
        data: [65, 59, 80, 81, 56, 55],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
      },
    ],
  });
});

// Route for dynamic data from MongoDB
router.get('/dynamic-chart-data', async (req, res) => {
  try {
    const chartData = await ChartData.findOne(); // Fetch data from MongoDB
    if (!chartData) {
      return res.status(404).json({ msg: 'No dynamic chart data found' });
    }
    res.json(chartData);
  } catch (error) {
    console.error('Failed to retrieve data:', error);
    res.status(500).send('Server error');
  }
});

module.exports = router;
